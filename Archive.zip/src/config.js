// ======================= config.js =======================
//   الإعدادات العامة للبوت — متكاملة مع نظام الدومينات
// =========================================================

module.exports = {
  // 🔐 إعدادات البوت
  BOT_TOKEN: "7608266485:AAFX4ZoikwZ1ObFGPsnvv8E3stkD3bZ2kKc",
  BOT_USERNAME: "russenumber_bot",

  // 🎁 مكافأة الإحالة
  REFERRAL_REWARD: 1,

  // 🌐 Cloudflare — الإعدادات
  CF_API_KEY: "bEiJCdSWanNWmkQL9GYmNLHGHVFCEarFCJlS0evk",
  CF_EMAIL: "Mohamedeldony18@gmail.com",
  CF_ZONE_ID: "be020e3d2b71d0a4da751a329a04a380",

  // 🏷️ الدومين الأساسي الذي سيتم إنشاء السبو دومينات منه
  ROOT_DOMAIN: "speedhost.store",   // ← عدله حسب الدومين الخاص بك

  // 🔢 الحد الأقصى لعدد السبو دومينات لكل مستخدم
  MAX_SUBDOMAINS: 3
};